import React from 'react'
import "./Locatsiya.css"

function Locatsiya() {
    return (
        <div>

<div className="loc">  <iframe className='locatsiya' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d95901.41990287448!2d69.2518912!3d41.3106176!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x38ae8b40d847941d%3A0x5765a18b352df71e!2sTashkent%20City%20Park!5e0!3m2!1sru!2s!4v1685364116689!5m2!1sru!2s" width="600" height="450" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>
          
        </div>
    )
}

export default Locatsiya